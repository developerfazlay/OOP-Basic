<?php

namespace exper;
class Qualification{
    function experienceList(){
        return "This is experience class info";
    }
}