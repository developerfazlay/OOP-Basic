<?php

namespace quali;
class Qualification{
    function qualificationList(){
        return "This is qualification list";
    }
}